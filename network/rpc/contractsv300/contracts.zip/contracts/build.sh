#!/bin/sh
abigen --sol MonitoringService.sol --pkg monitoringcontracts --out monitoringcontracts/MonitoringService.go  
abigen --sol TokenNetworkRegistry.sol  --pkg contracts --out TokenNetworkRegistry.go  
